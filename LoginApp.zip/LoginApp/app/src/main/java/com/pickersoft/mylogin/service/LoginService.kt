package com.pickersoft.mylogin.service

import com.pickersoft.mylogin.login.Login
import com.pickersoft.mylogin.login.Send
import retrofit2.Call
import retrofit2.http.*

interface LoginService {

    @POST("/api/signup")
    fun requestLogin(
        @Body UserDto: Send,
    ) : Call<Login>

}