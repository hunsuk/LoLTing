package com.pickersoft.mylogin.login

import com.google.gson.annotations.SerializedName

data class Login (
    @SerializedName("username") val username : String,
    @SerializedName("nickname") val nickname : String,
    @SerializedName("authorityDtoSet") val authorityDtoSet : ArrayList<Datalist.Auth>
)



