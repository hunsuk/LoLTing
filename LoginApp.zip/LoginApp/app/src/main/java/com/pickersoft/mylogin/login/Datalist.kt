package com.pickersoft.mylogin.login

import com.google.gson.annotations.SerializedName

class Datalist(){
    data class Auth(
        @SerializedName("authorityName") val authorityName : String
    )
}
