package com.pickersoft.mylogin.login

import com.google.gson.annotations.SerializedName

data class Send(
    @SerializedName("username") var username :String,
    @SerializedName("password") var password :String,
    @SerializedName("nickname") var nickname :String
)
