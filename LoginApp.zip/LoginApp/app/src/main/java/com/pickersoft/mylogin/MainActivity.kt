package com.pickersoft.mylogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.pickersoft.mylogin.login.Login
import com.pickersoft.mylogin.login.Send
import com.pickersoft.mylogin.service.LoginService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    var login:Login? = null

    var retrofit = Retrofit.Builder()
        .baseUrl("http://172.16.149.61:8080")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    var loginService: LoginService = retrofit.create(LoginService::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textId = findViewById<EditText>(R.id.editTextId).text
        val textPass = findViewById<EditText>(R.id.editTextTextPassword).text
        var textNickname = findViewById<EditText>(R.id.editTextId2).text
        val button = findViewById<Button>(R.id.btnLogin)

        button.setOnClickListener {
            val textTitle = findViewById<TextView>(R.id.textViewTitle).toString()


//            Log.d("LOGIN", "msg : " + textId.toString())
//            Log.d("LOGIN", "code : " + textPass.toString())
//            Log.d("LOGIN", "author : " + textNickname.toString())

            val loginInputData = Send(username = textId.toString(), password = textPass.toString(), nickname = textNickname.toString())

            //2nd, id and password matching function.

            loginService.requestLogin(loginInputData).enqueue(object : Callback<Login> {
                override fun onFailure(call: Call<Login>, t: Throwable) {
                    Log.e("LOGIN", t.message.toString())
                    var dialog = AlertDialog.Builder(this@MainActivity)
                    dialog.setTitle("에러")
                    dialog.setMessage("호출실패했습니다.")
                    dialog.show()
                }

                override fun onResponse(call: Call<Login>, response: Response<Login>) {
                    login = response.body()
                    Log.d("LOGIN", "dody : " + response.body().toString())
                    Log.d("LOGIN", "user : " + login?.username)
                    Log.d("LOGIN", "nick : " + login?.nickname)
                    Log.d("LOGIN", "author : " + login?.authorityDtoSet?.get(0)?.authorityName)
                    var dialog = AlertDialog.Builder(this@MainActivity)
                    dialog.setTitle(login?.username)
                    dialog.setMessage(login?.nickname)
                    dialog.setMessage(login?.authorityDtoSet?.get(0)?.authorityName)
                    dialog.show()
                }
            })



        }
    }
}